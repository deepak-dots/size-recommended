import {
  Page,
  Layout,
  Card,
  Button,
  Badge,
  Text,
  Stack,
  DataTable,
  TextField,
  Icon,
  // Toast,
} from "@shopify/polaris";
import { SearchMinor } from "@shopify/polaris-icons";
import { useState, useEffect } from "react";
import axios from "axios";
import QuickLinks from "./QuickLinks";
import CSVUpload from "./CSVUpload";  

export default function SizeDataManagement() {
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState("");
  // const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);

  // Fetch brand list
  const fetchBrands = async () => {
    setLoading(true);
    try {
      const response = await axios.get("api/proxy/v1/brands-list");
      const data = response.data.data; // Make sure backend returns { data: [...] }

      const formattedRows = data.map((brand) => [
        brand.name || "N/A",
        <Badge>{brand.category || "General"}</Badge>,
        brand.mapped_sizes || "-",
        new Date(brand.updated_at || brand.created_at).toLocaleDateString(),
        <Badge status={brand.status === "draft" ? "attention" : "success"}>
          {brand.status === "draft" ? "Draft" : "Live"}
        </Badge>,
        "⋮",
      ]);

      setRows(formattedRows);
    } catch (error) {
      console.error("Error fetching brands:", error);
      // setToast({ content: "Failed to load brands", error: true });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBrands();
  }, []);

  // CSV Upload Handler
  // const handleCSVUpload = async (event) => {
  //   const file = event.target.files[0];
  //   if (!file) return;

  //   const formData = new FormData();
  //   formData.append("csv_file", file);

  //   try {
  //     const response = await axios.post("api/proxy/v1/import-csv", formData, {
  //       headers: { "Content-Type": "multipart/form-data" },
  //     });
  //     // setToast({ content: response.data.message || "CSV uploaded successfully" });
  //     alert(response.data.message)
  //     fetchBrands(); // Refresh table
  //   } catch (error) {
  //     console.error("CSV upload error:", error);
  //     // setToast({ content: "Failed to upload CSV", error: true });
  //   }
  // };

  // Filter rows by search
  const filteredRows = rows.filter((row) =>
    row[0].toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Page
      fullWidth
      title="Size Data Management"
      subtitle="Manage specialized sizing charts for AFO-friendly, extra-wide, and brace-compatible footwear."
    >
      {/* {toast && <Toast content={toast.content} onDismiss={() => setToast(null)} />} */}

      <Layout>
        <Layout.Section>
          <Stack distribution="fill" spacing="tight">
            {/* 10% Block - Tips */}
            <Stack.Item fill={false} style={{ width: "10%" }}>
              <Card>
                <Card.Section>
                  <Text as="p" fontWeight="regular">
                    <Stack.Item fill={false} style={{ width: "20%" }}>
                          <QuickLinks />
                    </Stack.Item>

                  </Text>
                </Card.Section>
              </Card>
            </Stack.Item>

            {/* 60% Block - Brand List */}
            <Stack.Item fill={false} style={{ width: "60%" }}>
              <Card>
                <Card.Section>
                  {/* Search */}
                  <div style={{ marginBottom: "16px" }}>
                    <TextField
                      placeholder="Search brands or categories..."
                      prefix={<Icon source={SearchMinor} />}
                      value={search}
                      onChange={setSearch}
                    />
                  </div>

                  {/* Data Table */}
                  <DataTable
                    columnContentTypes={["text", "text", "text", "text", "text", "text"]}
                    headings={[
                      "Brand",
                      "Specialist Category",
                      "Mapped Sizes",
                      "Last Modified",
                      "Visibility",
                      "Actions",
                    ]}
                    rows={filteredRows}
                    footerContent={`Showing ${filteredRows.length} of ${rows.length} brands`}
                    loading={loading}
                  />
                </Card.Section>
              </Card>
            </Stack.Item>

            {/* 30% Block - CSV Upload */}
            <Stack.Item fill={false} style={{ width: "30%" }}>
              <Stack.Item fill={false} style={{ width: "30%" }}>
                <CSVUpload onUploadSuccess={fetchBrands} />
              </Stack.Item>
              {/* <Card>
                <Card.Section>
                  <Stack.Item fill={false} style={{ width: "30%" }}>
                    <CSVUpload onUploadSuccess={fetchBrands} />
                  </Stack.Item>
                  <Stack vertical spacing="tight">
                    <Text variant="headingSm">Upload CSV</Text>
                    <Text as="p">
                      Upload your brand CSV including all sizing and measurement data.
                    </Text>
                    <Button onClick={() => document.getElementById("csv-input").click()}>
                      Upload CSV
                    </Button>
                    <input
                      id="csv-input"
                      type="file"
                      accept=".csv"
                      style={{ display: "none" }}
                      onChange={handleCSVUpload}
                    />
                  </Stack>
                </Card.Section>
              </Card> */}
            </Stack.Item>
          </Stack>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
